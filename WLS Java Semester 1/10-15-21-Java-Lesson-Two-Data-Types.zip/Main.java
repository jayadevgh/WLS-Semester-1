class Main {
  public static void main(String[] args) {
    System.out.println("Hello world!");
    // Let's look at how to convert from one data type to another
    // When the number is already possible to convert from one to another there is no need of type casting

    int x = 5;
    double y = x;
    System.out.println(y);

    //When converting from a double to an int however, a fractional number cannot be an integer directly so you have to type cast it into an int.
    double double1 = 5.87;
    int int1 = (int)double1;
    System.out.println(int1);

  }  
}