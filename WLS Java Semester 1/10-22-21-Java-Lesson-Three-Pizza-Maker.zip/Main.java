import java.util.Scanner;
class Main {
  public static void main(String[] args) {
    Scanner sc = new Scanner(System.in);
    
    System.out.println("Hello! Welcome to the pizzaria. Please input your favorite choice of pizza.");

    String pizzaInput = sc.nextLine();

    System.out.println("Thank you for inputting your type of pizza. What is your preferrence for both toppings.");

    System.out.println("Enter your first choice of topping:");
    String toppingInput1 = sc.nextLine();

    System.out.println("Enter your second choice of topping:");
    String toppingInput2 = sc.nextLine();

    System.out.println("Thank you for shopping at the pizzaria. Here is your recipt.");
    
    System.out.println("Pizza Choice: " + pizzaInput);
    System.out.println("Topping Choices: " + toppingInput1 + 
    " and " + toppingInput2);
  }
}