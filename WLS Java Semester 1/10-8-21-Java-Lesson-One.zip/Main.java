class Main { //This is a class
  public static void main(String[] args) { 
    System.out.println("Hello world!"); //This prints Hello World 
    String x = "hi"; // This variable is a string
    int number1 = 5; // This variable is an integer
    int number2 = 10;
    System.out.println(number1 + number2);
    System.out.println(x);
    // This is a comment
    /* Every thing written within the slash star braces will be a comment. */
  }
}