import java.util.Scanner;
class Main {
  public static void main(String[] args) {
    //Here we are creating an instance of the Scanner class and we get to access all functions in the Scanner class
    Scanner sc = new Scanner(System.in);

    //The nextLine() function is used for Strings
    String input = sc.nextLine();
    System.out.println(input);

    //The nextInt() function is used for Integer so make sure you only give a number as an input. Otherwise, the program will throw an error.
    int intInput = sc.nextInt();
    System.out.println("Here is your number with 5 added to it.");
    System.out.println(5+intInput);
  }
}