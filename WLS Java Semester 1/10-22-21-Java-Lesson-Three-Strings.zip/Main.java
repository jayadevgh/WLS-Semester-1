class Main {
  public static void main(String[] args) {
    System.out.println("Hello world!");

    String str = "This is a string"; 
    // Our string is surrounded by two quotation marks and the first letter of the name of the data type is capital
    System.out.println(str);

    String firstName = "Bill";
    String lastName = "Smith";
    System.out.println(firstName + " " + lastName);

    String compoundWord = "race" + "car";

    //Here is the fix using backslashes
    String bookReview = "I really liked the book \"The Outsiders\".";
    System.out.println(bookReview);
    
    int compoundWordLength = compoundWord.length();
    // Here I am finding the length of compoundWord by using the length function in String

    System.out.println("The length of the variable \'compoundWord\' is "+ compoundWordLength + " letters long");

    System.out.println(firstName.concat(lastName));

    System.out.println(compoundWord.equals("race".concat("car")));
  }
}